

<?php $__env->startSection('content'); ?>
<div style="width:60% ; margin-left: 20%;">
<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name of the Field</th>
                <th>Date</th>
                <th>Name of the Tractor</th>
                <th>Processed Area</th>                
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>            
           <td><?php echo e($processs->selectafield); ?></td>
           <td><?php echo e($processs->date); ?></td>
           <td><?php echo e($processs->selectatractor); ?></td>
           <td><?php echo e($processs->area); ?></td>           
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Name of the Field</th>
                <th>Date</th>
                <th>Name of the Tractor</th>
                <th>Processed Area</th>  
            </tr>
        </tfoot>
    </table>

    </div>
    
    <!-- DataTable JS -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable( {
                initComplete: function () {
                    this.api().columns().every( function () {
                        var column = this;
                        var select = $('<select><option value=""></option></select>')
                            .appendTo( $(column.header()).empty() )
                            .on( 'change', function () {
                                var val = $.fn.dataTable.util.escapeRegex(
                                    $(this).val()
                                );
        
                                column
                                    .search( val ? '^'+val+'$' : '', true, false )
                                    .draw();
                            } );
        
                        column.data().unique().sort().each( function ( d, j ) {
                            select.append( '<option value="'+d+'">'+d+'</option>' )
                        } );
                    } );
                }
            } );
        } );
    </script>
    <?php $__env->stopSection(); ?>

    
   
    


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/rest-api/resources/views/reports/reports.blade.php ENDPATH**/ ?>