

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="<?php echo e(url('/tractor/create')); ?>" class="btn btn-primary">Add Tractor</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header"><?php echo e(__('Tractors')); ?></div>

<div class="card-body">
<table class="table table-striped">
    <thead>
        <tr>            
            <th> Tractor Name</th>                                  
        </tr>
    </thead>
    <tbody>       
    <?php $__currentLoopData = $tractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <tr>
              <td> <?php echo e($tractor->tractor_name); ?> </td>              
              <td><a class="btn btn-primary" href="/tractor/edit/<?php echo e($tractor->id); ?>">Edit</a> <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="/tractor/delete/<?php echo e($tractor->id); ?>">Delete</a></td>             
          </tr>         
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/rest-api/resources/views/tractors/tractors.blade.php ENDPATH**/ ?>