<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::middleware('auth:api')->group( function () {
	Route::resource('products', 'API\ProductController');
});

Route::post('/register', 'API\RegisterController@register');


Route::get('/field', 'FieldController@index')->name('field');
Route::get('/field/create', 'FieldController@create')->name('field');
Route::get('/tractor/create', 'TractorController@create')->name('tractor');
Route::get('/process/create', 'ProcessController@create')->name('process');
Route::post('/tractor/store', 'TractorController@store')->name('tractor');
Route::post('/field/store', 'FieldController@store')->name('field');
Route::post('/process/store', 'ProcessController@store')->name('process');
Route::get('/field/edit/{id}', 'FieldController@show')->name('field');
Route::get('/tractor/edit/{id}', 'TractorController@show')->name('tractor');
Route::get('/process/edit/{id}', 'ProcessController@show')->name('process');
Route::post('/tractor/update/{id}', 'TractorController@update')->name('tractor');
Route::post('/process/update/{id}', 'ProcessController@update')->name('process');
Route::post('/field/update/{id}', 'FieldController@update')->name('field');
Route::get('/field/delete/{id}', 'FieldController@destroy')->name('field');
Route::get('/tractor/delete/{id}', 'TractorController@destroy')->name('tractor');
Route::get('/process/delete/{id}', 'ProcessController@destroy')->name('process');
Route::get('/tractor', 'TractorController@index')->name('tractor');
Route::get('/process', 'ProcessController@index')->name('process');
Route::get('/reports', 'ReportsController@index')->name('reports');
